from ._sockio import INET_TCP, UDS_TCP, SOCKIO_XCEPT

__all__ = ['INET_TCP']
